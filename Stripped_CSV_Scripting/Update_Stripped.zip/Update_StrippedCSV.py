# Title:    Update_StrippedCSV.py
# Author:   Tyler D. Morris N3TDM
# Date:     2/25/2021

# Import necessary python packages
from lxml import html, etree
import requests
import wget
import subprocess

# Get webpage content
pageLink = "https://kf5iw.com/"
page = requests.get("https://kf5iw.com/contactdb.php")

# Extract HTML from the webpage
extractedHTML = html.fromstring(page.content)

# Store partial file link as variable
partialFileLink = extractedHTML.xpath("/html/body/main/div/div[3]/div/table/tbody/tr[1]/td[1]//a[1]/@href")

# Store Full Filename link as fileLInk variable
fileLink = str(pageLink) + str(partialFileLink[0])

# Get filename
fileName = fileLink.split("/")[-1]

# Download File
wget.download(fileLink, '/tmp/DMRDatabase.zip')

# Call shell script to continue with unzipping, reordering columns, and moving the file
cmd = subprocess.call('/home/pi-star/' + 'update_dmr_ids.sh')
