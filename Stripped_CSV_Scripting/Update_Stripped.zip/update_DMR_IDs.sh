#!/bin/bash
# Author: Tyler D. Morris N3TDM
# Description: unzip downloaded dmr database file, reorder columns, delete last 3 columns, replace stripped.csv
# Date:   02/25/2021

# Make sure RPI filesystem is read/write
sudo mount -o remount,rw / ; sudo mount -o remount,rw /boot

# change to pi-star home directory
cd /tmp

# Delete all existing .csv files BEFORE unzipping DMRDatabase.zip file
sudo del *.csv

# Unzip Downloaded DMRDatabase.zip file
sudo unzip DMRDatabase.zip

# Move and Rename unzipped DMRDatabase.csv to stripped.csv
sudo mv /tmp/DMRDatabase/contacts_ALL_*.csv /tmp/contacts.csv

# Delete last 3 columns
cut -d, -f8-10 --complement contacts.csv > contacts_Edited.csv

# Move first column to new position
awk -F, '{print $2,$3,$4,$1,$5,$6,$7}' OFS=, "contacts_Edited.csv" > stripped.csv

# Copy updated stripped.csv file over the old stripped.csv file
sudo cp /tmp/stripped.csv /usr/local/etc/stripped.csv

# Reboot
sudo reboot
